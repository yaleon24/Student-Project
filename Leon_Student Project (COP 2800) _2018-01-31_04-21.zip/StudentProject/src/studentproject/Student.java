/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner;

/**
 *
 * Create a Student class that can keep track of the name of the student as well as the scores for three tests.
 * Provide a constructor that sets all instance values based on parameter values.  Overload the constructor such that each test score is set to zero.
 * Provide a method called setTestScore that accepts two parameters: the test number (1 through 3) and the score.
 * Also provide a method called getTestScore that accepts the test number and returns the appropriate score.
 * Provide a method average that computes and returns the average test score for this student.
 *
 */public class Student {
    int exam;
    double testscore, test1, test2, test3;
    String name;

    public Student(double test1, double test2, double test3, String name) {
        this.test1 = test1;
        this.test2 = test2;
        this.test3 = test3;
        this.name = name;
    }
//////////////////////////////////////////////////////////////////////
    public Student(String name) {
        this.name = name;
        test1 = 0;
        test2 = 0;
        test3 = 0;
    }
    //////////////////////////////////////////////////
    public void setTestScore(int test, double score){
       if (test == 1) {
           this.testscore = score;
           test1 = score;
       }
       else if (test == 2) {
           this.testscore = score;
           test2 = score;
       }
       else if (test == 3) {
           this.testscore = score;
           test3 = score;
       }
       else {
           
       }
    }
    
    public double getTestScore(int test){
        return testscore;
    }
    
    public double average(){
        double average = (test1+test2+test3)/3;
        return average;
    }



    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the name:");
        String name = scanner.nextLine();
        System.out.println("If you know the three test scores, enter 1.");
        while(!scanner.hasNextInt()) scanner.next();
        int userInput = scanner.nextInt();
        Student student;
        if(userInput == 1){
            System.out.println("Enter the three test scores:");
            while(!scanner.hasNextDouble()) scanner.next();
            double test1 = scanner.nextDouble();
            while(!scanner.hasNextDouble()) scanner.next();
            double test2 = scanner.nextDouble();
            while(!scanner.hasNextDouble()) scanner.next();
            double test3 = scanner.nextDouble();
            student = new Student(test1, test2, test3, name);
        }
        else{
            student = new Student(name);
        }
        System.out.println("Enter 1 to change a test score.");
        while(!scanner.hasNextInt()) scanner.next();
        userInput = scanner.nextInt();
        if(userInput == 1){
            System.out.println("Enter the test score to change:");
            while(!scanner.hasNextInt()) scanner.next();
            int testChange = scanner.nextInt();
            System.out.println("Enter the new score:");
            while(!scanner.hasNextDouble()) scanner.next();
            double newScore = scanner.nextDouble();
            student.setTestScore(testChange, newScore);
        }
        System.out.println("Enter 1 to view a test score.");
        while(!scanner.hasNextInt()) scanner.next();
        userInput = scanner.nextInt();
        if(userInput == 1){
            System.out.println("Enter the test score to view:");
            while(!scanner.hasNextInt()) scanner.next();
            int testScore = scanner.nextInt();
            System.out.println(student.getTestScore(testScore));
        }
        System.out.println("Average " + student.average());
        System.out.println();
    }
}
